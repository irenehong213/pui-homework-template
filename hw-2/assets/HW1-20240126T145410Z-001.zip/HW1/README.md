# HW1 Materials

Find the materials for your homework here:
* The mockups for all webpages for closer inspection, if needed. Reminder: you don't have to be pixel-accurate; the overall proportions should match.
* The logo: download and use in your webpage design
* The product photos: download them and use in your webpage design

Your page should be self-contained! Download the assets and push to your repository. Do not link to the assets in this repository.
